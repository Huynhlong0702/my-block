const enouvoIcons = [
	{
		'fa fa-facebook' : 'fa fa-facebook',
	},
	{
		'fa fa-youtube' : 'fa fa-youtube',
	},
	{
		'fa fa-instagram' : 'fa fa-facebook',
	},
	{
		'fa fa-twitter' : 'fa fa-twitter',
	}
];

export default enouvoIcons;