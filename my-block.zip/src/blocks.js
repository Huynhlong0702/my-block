
// import './block/blog/blog.js';
import './block/service/service.js';
import './block/heading/heading.js';
import './block/review/review.js';
import './block/featured/featured.js';
import './block/test/test.js';
import './block/test2/test2.js';
import './block/test3/test3.js';

